/*

a. The info member of Node 1, referenced from pointer C
C->next->info

b. The info member of Node 2, referenced from pointer B
B->back->info

c. The next member of Node 2, referenced from pointer A
A->next->next

d. The next member of Node 4, referenced from pointer C
C->back->next

e. Node 1, referenced from pointer B
B->back->back

f. The back member of Node 4, referenced from pointer C
C->back->back

g. The back member of Node 1, referenced from pointer A
A->back
 
 */