/*
 a. F. the function will always return 0. please use nullptr instead of NULL

 b. D. the function doesn't produce sum of squared values but sum of their original values. please use nullptr instead of NULL

 c. A0. works fine, but not using parenthese {} when you only have a single statement is a bad practice. please use nullptr instead of NULL

 d. B+. works fine unless list is nullptr, but not using parenthese {} when you only have a single statement is a bad practice. please use nullptr instead of NULL

 e. C-. wrong equation. will always return 0. please use nullptr instead of NULL
 */