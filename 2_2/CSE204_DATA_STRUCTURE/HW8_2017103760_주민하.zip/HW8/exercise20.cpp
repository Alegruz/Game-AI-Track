/*
 list
 .length	20
 .info		2	6	9	14	23	65	92	96	99	100
			[0]	[1]	[2]	[3]	[4]	[5]	[6]	[7]	[8]	[9]

 BinarySearch(info, 99, 0, 9);


 call	fromLocation	toLocation	result	return address
 1		0				99			?>true	2048
 2		50				99			?>true	1024
 3		75				99			?>true	1024
 4		88				99			?>true	1024
 5		94				99			?>true	1024
 6		97				99			?>true	1024
 7		99				99			true	1024

 */