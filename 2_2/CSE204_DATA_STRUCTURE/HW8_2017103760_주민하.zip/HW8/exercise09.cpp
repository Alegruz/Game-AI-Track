/*
 a. num shouldn't be a positive integer which creates infinite loop

 b. no. infinite loop

 c. yes. 0

 d. yes. -15

 */