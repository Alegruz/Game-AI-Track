#pragma once

template<typename T>
struct Node
{
    T mInfo;
    Node* mNext;
};