#pragma once

#include "Student.h"

void HeapSort(Student values[], int numValues);