#pragma once

template<class ItemType>
struct NodeType
{
    ItemType info;
    NodeType* next;
};