#include "LLHeapType.h"

void SwapInt(int& i, int& j)
{
	int temp = i;
	i = j;
	j = temp;
}
