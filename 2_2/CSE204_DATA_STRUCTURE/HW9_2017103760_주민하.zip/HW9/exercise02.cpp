/*
 2. Which of these formulas gives the maximum total number of nodes in a tree that has N levels? (Remember that the root is Level 0.)
 a. N^2 - 1
 b. 2^N
 c. 2^N - 1
 d. 2^(N + 1)

 2^(N + 1) - 1 if total nodes
 c. if internal nodes only

 */