/*
 3. Which of these formulas gives the maximum number of nodes in the Nth level of a binary tree?
 a. N^2
 b. 2^N
 c. 2^(N+1)
 d. 2^N - 1

 b.

 */