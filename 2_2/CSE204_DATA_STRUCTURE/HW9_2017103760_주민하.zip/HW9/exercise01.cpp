/*
 a. What does the level of a binary search tree mean in relation to its searching efficiency?
the level is translated into the maximum cases of comparisons for a single search.

 b. What  is  the  maximum  number  of  levels  that  a  binary  search  tree  with  100 nodes can have?
 100

 c. What  is  the  minimum  number  of  levels  that  a  binary  search  tree  with  100 nodes can have?
7
 */