/*
 How many ancestors does a node in the Nth level of a binary search tree have?

 N

 */