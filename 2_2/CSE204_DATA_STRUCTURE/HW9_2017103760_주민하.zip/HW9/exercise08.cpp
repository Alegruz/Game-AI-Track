/*
 a. What are the ancestors of node P?
 M K Q
 
 b. What are the descendants of node K?
 D B J M P N
 
 c. What is the maximum possible number of nodes in the tree at the level of node W?
 8
 
 d. What is the maximum possible number of nodes in the tree at the level of node N?
 16
 
 e. Insert node O. How many nodes would be in the tree if it were completely fulldown to and including the level of node O?
 2^6 - 1 = 63

 */