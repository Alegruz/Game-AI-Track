/*
 a. How many different binary trees can be made from three nodes that contain the key values 1, 2, and 3?
 6 * 5 = 30
 
 b. How many different binary search trees can be made from three nodes that contain the key values 1, 2, and 3?
 5

 */