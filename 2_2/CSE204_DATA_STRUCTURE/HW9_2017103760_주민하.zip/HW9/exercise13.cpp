/*
 a. Trace the path that would be followed in searching for a node containing 61.
 56->69->59->62->61
 
 b. Trace the path that would be followed in searching for a node containing 28.
 56->47->22->29->23->nullptr

 */