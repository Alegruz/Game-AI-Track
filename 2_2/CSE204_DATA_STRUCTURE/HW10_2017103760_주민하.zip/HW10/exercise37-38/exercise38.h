/*
 it is implementation-defined
 
 either node 5 or node 6
 */