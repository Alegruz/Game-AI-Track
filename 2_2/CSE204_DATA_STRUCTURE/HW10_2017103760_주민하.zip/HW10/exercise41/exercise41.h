/*
 a.
 free	8
 root	0
			.info	.left	.right
 nodes	0	'Q'		1		2
		1	'L'		3		4
		2	'W'		5		nullptr
		3	'F'		nullptr	nullptr
		4	'M'		nullptr	6
		5	'R'		nullptr	7
		6	'N'		nullptr	nullptr
		7	'S'		nullptr	nullptr
		8	?		9		nullptr
		9	?		nullptr	nullptr

 b.
 free	9
 root	0
			.info	.left	.right
 nodes	0	'Q'		1		2
		1	'L'		3		4
		2	'W'		7		nullptr
		3	'F'		8		nullptr
		4	'M'		nullptr	6
		5	?		nullptr	nullptr
		6	'N'		nullptr	nullptr
		7	'S'		nullptr	nullptr
		8	'B'		nullptr	nullptr
		9	?		5		nullptr
 */