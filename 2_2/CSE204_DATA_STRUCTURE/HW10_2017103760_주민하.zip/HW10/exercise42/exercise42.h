/*
 a. complete?
 (b), (d), (e)

 b. full?
 (b), (d), (e), (f)

 */