/*
 a. true
 b. false
 c. false
 d. true
 7 > 16 > 34 > 70
   > 15 > 31 > 63
 e. false
 log2(85) = log2(64) * ? = 6 * ?
 6 levels are full
 */